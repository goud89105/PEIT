package com.springbootwithswaggerjunit.springbootwithswaggerjunit;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootwithswaggerjunitApplicationTests {

	@Test
	void contextLoads() {
	}

}
