package com.springbootwithswaggerjunit.springbootwithswaggerjunit.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.springbootwithswaggerjunit.springbootwithswaggerjunit.model.Student;

@Repository
public interface StudentRepo extends JpaRepository<Student,Integer>{

//	List<Student> findByAddress(String address);
}
