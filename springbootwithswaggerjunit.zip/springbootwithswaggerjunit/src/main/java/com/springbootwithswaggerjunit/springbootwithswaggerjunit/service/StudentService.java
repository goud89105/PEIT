package com.springbootwithswaggerjunit.springbootwithswaggerjunit.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import com.springbootwithswaggerjunit.springbootwithswaggerjunit.model.Student;
import com.springbootwithswaggerjunit.springbootwithswaggerjunit.repository.StudentRepo;

@Service
public class StudentService {

	
	@Autowired
	StudentRepo studentRepo;
	
	public Student SaveStudentdata(Student student)
	{
		
		studentRepo.save(student);
		return student;
		
	}
	
	public List<Student> getstudentData()
	{
		
		return studentRepo.findAll();
		
	}
	
	public Student deletestudentData(Student student)
	{
		studentRepo.delete(student);
		return student;
		
	}
	
	/*
	 * public List<Student> getUserbyAddress(String address) { return
	 * studentRepo.findByAddress(address); }
	 */
}
