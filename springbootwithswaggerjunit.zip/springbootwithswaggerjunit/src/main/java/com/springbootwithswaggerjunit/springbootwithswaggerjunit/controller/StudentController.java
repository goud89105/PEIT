package com.springbootwithswaggerjunit.springbootwithswaggerjunit.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.springbootwithswaggerjunit.springbootwithswaggerjunit.model.Student;
import com.springbootwithswaggerjunit.springbootwithswaggerjunit.service.StudentService;

@RestController
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	StudentService studentService;

	@PostMapping("/savedata")
	public Student SaveStudent(@RequestBody Student student)
	{
		
		return studentService.SaveStudentdata(student);
		
	}
	
	@GetMapping("/getdata")
	public List<Student> getData()
	{
		
		return studentService.getstudentData();
		
	}
	
	@DeleteMapping("/deletedata")
	public Student deleteData(@RequestBody Student student)
	{
		
		return studentService.deletestudentData(student);
		
	}
	
	/*
	 * @GetMapping("/getUserByAddress/{address}") public List<Student>
	 * findUserByAddress(@PathVariable String address) { return
	 * studentService.getUserbyAddress(address); }
	 */
}
